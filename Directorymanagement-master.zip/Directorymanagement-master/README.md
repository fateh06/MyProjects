# Directorymanagement

Size Ödev:
	Uygulama içinde iki textBox olsun
	ilk textbox'tan bir veri kopyalandığında
	diğer textbox'a yapıştırma mümkün olsun
	
	Defalarca kopyalama yapılırsa
	Geçmişe yönelik kopyalanan değerler de 
	aranıp yapıştırılabilsin
