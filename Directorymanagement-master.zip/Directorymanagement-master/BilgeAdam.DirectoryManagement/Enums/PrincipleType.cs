﻿namespace BilgeAdam.DirectoryManagement.Enums
{
    public enum PrincipleType
    {
        Root = 0,
        User = 1,
        Group = 2
    }
}
